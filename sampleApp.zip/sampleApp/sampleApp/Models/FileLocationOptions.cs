﻿namespace sampleApp.Models
{
    public class FileLocationOptions
    {
        public const string FileLocation = "FileLocation";
        public string FilePath { get; set; }
    }
}
